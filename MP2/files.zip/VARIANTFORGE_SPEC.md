# VariantForge — Product Specification
> Version 1.1 · Ready for Cursor handoff

---

## What It Is

A web app that takes a single SVG design template and generates unlimited customised variants — different text, images, colours, and fonts — driven by a CSV upload, an AI prompt, or both together.

**Use cases:** restaurant cards, invitations, certificates, multilingual assets, A/B copy testing, seasonal variants, client presentations, greeting cards.

---

## Core Loop

```
Upload SVG Template
        ↓
Auto-detect all layers (text, images, shapes, decorative elements)
        ↓
Input: AI prompt bar + optional CSV upload (either or both)
        ↓
Gemini 2.5 Flash maps data → generates variant definitions (JSON)
        ↓
Fabric.js renders variants on the drafting board canvas
        ↓
User pans, zooms, clicks to edit inline, undoes/redoes
        ↓
Export as SVG or PNG ZIP (PDF and Figma push — Phase 2)
```

---

## Layer Detection

### Recommended: Named Layers
For complex SVGs, users should name variable layers in Figma or Illustrator before exporting using double bracket syntax. The parser looks for this pattern specifically and ignores everything else.

```
{{restaurant_name}}   →   text variable
{{hero_image}}        →   image variable
{{bg_color}}          →   shape/fill variable
```

### Fallback: Auto Detection
For simple flat SVGs with no named layers, Gemini reads the SVG structure and makes educated guesses based on text content, element size, and position. Works well for simple to medium complexity files.

### Safety Net: User Selection
After parsing, the Layers tab shows every detectable text and image element with a preview of its current content. The user can toggle which ones become variables and name them. This works for any SVG regardless of complexity.

| Layer Type | Detected By | Customisable |
|---|---|---|
| Text | `<text>`, `<tspan>` | Content, colour, font, size |
| Image placeholder | `<image>` or `<rect>` with image fill | Image source |
| Decorative shape | `<rect>`, `<circle>`, `<ellipse>`, `<path>` with solid fill | Fill colour, opacity |
| Background | Root-level fill or background rect | Colour |
| Grouped elements | `<g>` tags | Treated as a unit |

---

## Input Methods

### 1. AI Prompt Bar (primary)
Always visible in the right panel. Natural language drives everything.

```
"Generate 8 variants — playful, luxury, urgent, minimal, friendly, bold, elegant, quirky"
"5 colour variants, warm sunset palette, serif font"
"Translate all text to French, Spanish, and Arabic"
"Give me 10 restaurant cards with made-up names and discount codes"
"Use my CSV but make the tone more upscale and colours more muted"
"Generate me 15 coffee shop entries with names, taglines, and promo codes"
"Change all the discount codes to 15% off"
```

### 2. CSV Upload (optional)
- User uploads their own CSV file
- Header row = column names (user-defined)
- Each row = one variant
- Columns map to: text content, image path/URL, hex colour, font name
- Gemini auto-maps columns to detected layers
- CSV is stored as a JSON array in memory — never shown as a raw editor

```csv
name,           tagline,               code,     photo,      bg_color,  font
Joe's Diner,    Taste the Difference,  SAVE20,   joes.jpg,   #FFF3E0,   Playfair Display
Pizza Palace,   Fresh Every Slice,     PIZZA10,  pizza.jpg,  #FCE4EC,   Lato
```

### 3. Both Together
CSV provides the data. Prompt provides creative direction layered on top.
`"Use my CSV but translate everything to Japanese and apply a luxury palette"`

---

## CSV Handling

CSV is an invisible engine, not a spreadsheet the user manages. Two ways it enters the tool:

- **User uploads a CSV file** — parsed via Papa Parse, stored as JSON array in memory
- **User describes data in prompt** — Gemini generates the CSV structure and populates it

Once in memory, all edits happen through natural language in the chat. Examples:

```
"Change all the discount codes to 15% off"
"Add a French translation column"
"The photo column should map to the image layer, not the name"
```

Gemini returns an updated JSON array on every edit. No manual CSV editing required at any point.

---

## Customisation Variables

### Text
- Content (swap, rewrite, translate, generate)
- Colour
- Font family (Google Fonts)
- Font size / weight / style
- Inline editing on canvas (click → Fabric IText)

### Images
- Local file upload bundled with CSV
- Direct URL in CSV column
- Stock photo search via Unsplash / Pexels (Phase 2)

### Colours
- Per-shape fill colour
- Background colour
- Text colour
- Opacity
- Gemini interprets plain language descriptions into hex values (`"warm terracotta"` → `#C17A5B`)

### Fonts
- Google Fonts library
- Set per variant via CSV column or prompt
- Graceful fallback if font unavailable

---

## AI — Gemini 2.5 Flash

**Model:** `gemini-2.5-flash`
**Tier:** Free (1,500 requests/day, 15 RPM, no credit card required)
**Pattern:** Send layer JSON + user prompt → receive variant definitions as JSON array

| Feature | Details |
|---|---|
| Copy generation | Text per layer per variant |
| Tone / style variation | Rewrites existing text in N tones |
| Translation | All text layers into target languages |
| Colour interpretation | Plain language descriptions to hex palettes |
| CSV generation | User describes data, Gemini builds the JSON array |
| CSV editing | Natural language edits to existing CSV data in memory |
| Auto column mapping | CSV columns matched to SVG layers |
| Font suggestion | Based on tone and style of the request |
| Out of scope handling | See section below |

### System Prompt (sent with every Gemini call)
```
You are the AI assistant inside VariantForge, a tool that generates 
static design variants from SVG templates using text, colour, image, 
and font customisation.

If a user asks for something outside this scope — animation, photo 
editing, logo creation from scratch, video output, or anything 
requiring a full design tool — acknowledge it briefly in one sentence, 
suggest the closest thing VariantForge can help with, and optionally 
name where they could go for that task instead. Keep responses short 
and helpful. Never just say you cannot do something without offering 
an alternative direction.
```

### Out of Scope Examples and Responses

| User asks | Gemini responds |
|---|---|
| "Animate this card" | Animation is outside VariantForge — export the SVG and bring it into After Effects or CSS. I can generate multiple style variants of this card if you want to explore different looks. |
| "Generate a logo for me" | Logo creation from scratch is beyond what this tool does — try Looka or Canva for that. I can apply your existing logo as an image variable across all your variants. |
| "Edit this photo" | Photo editing is not something VariantForge handles — Photoshop or remove.bg would help there. I can swap the image layer across variants with a different photo if you want. |
| "Make a video version" | Video output is outside the scope here — After Effects or CapCut would be the right place. I can generate as many static card variants as you need. |

---

## Canvas and Interaction (Fabric.js)

The central board is a Fabric.js instance. Handles all canvas interactions.

- **Pan** — spacebar + drag
- **Zoom** — scroll wheel, clamped min/max
- **Variant cards** — each rendered as a Fabric `Group`
- **Inline text editing** — click text layer → Fabric `IText` activates
- **Drag text bounding boxes** — move and resize directly on canvas
- **Colour shape selection** — click shape → colour picker popover
- **Undo / Redo** — JSON snapshot history stack, max 50 states

### History Stack Pattern
```js
const history = []
let historyIndex = -1

// On every canvas mutation:
history.splice(historyIndex + 1)
history.push(canvas.toJSON())
historyIndex++

// Ctrl+Z:
canvas.loadFromJSON(history[--historyIndex])

// Ctrl+Shift+Z:
canvas.loadFromJSON(history[++historyIndex])
```

---

## Motion.dev — UI Animations Only

Used exclusively for the React shell. Never used for canvas interactions.

| Element | Animation |
|---|---|
| Panel sections | Staggered slide-in on mount |
| Variant cards entering board | Spring physics, staggered per card |
| Prompt bar | Scale + glow on focus |
| Export row | Slides up when variants are ready |
| Layer list items | Stagger in when SVG is parsed |
| Toast notifications | Slide in / out |

---

## App Layout

```
┌──────────────────────────────────────────────┬──────────────┐
│  TOOLBAR (spans board only)                  │              │
│  Logo · Select/Pan · Undo/Redo · Zoom · Fit  │              │
├──────────────────────────────────────────────┤  RIGHT PANEL │
│                                              │  (320px)     │
│                                              │              │
│   FABRIC.JS DRAFTING BOARD (dominant)        │  ┌─────────┐ │
│                                              │  │  Tabs:  │ │
│   • Warm linen paper texture + noise grain   │  │ AI Chat │ │
│   • Major + minor graph paper grid           │  │ Layers  │ │
│   • Top + left ruler strips (IBM Plex Mono)  │  │ Style   │ │
│   • Vignette + inset frame shadow            │  └─────────┘ │
│   • Corner registration marks                │              │
│   • Board watermark bottom-left              │  [chat msgs] │
│   • Variant cards with tape strip + tilt     │  [chips]     │
│   • Navy/indigo tinted shadows               │  [prompt]    │
│   • Pan / zoom / inline edit / undo          │  [export row]│
├──────────────────────────────────────────────┤              │
│  STATUS BAR (floating pill, bottom center)   │              │
│  Ready · N variants · keyboard hints         │              │
└──────────────────────────────────────────────┴──────────────┘
```

### Component Tree
```
<App>
  <Toolbar>
    <Logo />
    <ToolGroup>          // Select, Pan
    <ToolGroup>          // Undo, Redo + kbd hint
    <ToolGroup>          // Fit, ZoomDisplay
    <ToolGroup>          // Preview, Share
  </Toolbar>

  <Layout>               // grid: 1fr 320px, 100vh
    <BoardArea>
      <RulerCorner />
      <RulerX />         // IBM Plex Mono ticks
      <RulerY />
      <BoardSurface>     // Fabric.js canvas
        <BoardFrame />   // inset shadow overlay
        <CornerMarks />  // registration marks x4
        <Watermark />
      </BoardSurface>
      <StatusBar />      // floating pill
    </BoardArea>

    <RightPanel>
      <PanelHead />      // "Workspace" label
      <PanelTabs />      // AI Chat / Layers / Style

      <TabBody name="ai">
        <ChatScroll />   // message history
        <ChipsRow />     // quick prompts
        <PromptBox />    // textarea + send
      </TabBody>

      <TabBody name="layers">
        <PanelScroll>
          <UploadZone /> // SVG upload
          <LayerList />  // Motion.dev stagger
          <CSVRow />     // CSV upload only, no editor
        </PanelScroll>
      </TabBody>

      <TabBody name="style">
        <PanelScroll>
          <ColourGrid /> // swatches
          <FontPicker /> // Google Fonts
        </PanelScroll>
      </TabBody>

      <ExportRow />      // Motion.dev slide-up
    </RightPanel>
  </Layout>

  <ToastStack />         // Motion.dev, bottom center
</App>
```

---

## Visual Design System

### Aesthetic
Dark chrome shell + warm linen drafting board. Feels like a physical design tool. Navy/indigo tinted shadows throughout — never pure black.

### Colour Tokens
```
--board-bg:         #F0EDE4                  warm linen
--board-line-major  rgba(160,140,100,0.22)   graph paper major
--board-line-minor  rgba(160,140,100,0.10)   graph paper minor

--chrome:           #1E1E1A                  toolbar + panel shell
--chrome-mid:       #2E2E28                  ruler strips
--panel-bg:         rgba(30,30,26,0.97)

--accent:           #C8A96E                  gold
--accent-dim:       rgba(200,169,110,0.12)
--accent-mid:       rgba(200,169,110,0.2)

--tx-primary:       #F0EDE4
--tx-secondary:     rgba(240,237,228,0.55)
--tx-muted:         rgba(240,237,228,0.3)

--shadow-base:      rgba(18,28,60,...)        navy tinted, all shadows
```

### Typography
- **UI labels / ruler / mono values:** IBM Plex Mono
- **Headings / logo:** DM Serif Display
- **Body / UI text:** DM Sans
- **Card titles:** DM Serif Display

### Card Details
- Slight random tilt per card (plus or minus 0.5deg) — feels placed, not rendered
- Translucent tape strip on top of each card
- Hover: snaps straight, lifts with deeper navy shadow
- Selected: gold outline `2px solid #C8A96E`

---

## Tech Stack (Locked)

### Frontend
| Package | Version | Purpose |
|---|---|---|
| React | 18+ | UI framework |
| Vite | 5+ | Build tool |
| Tailwind CSS | 3+ | Layout + utility styles |
| Fabric.js | 6+ | Board canvas, pan/zoom, editing, undo |
| Motion (Framer Motion) | 11+ | UI shell animations only |
| Papa Parse | 5+ | CSV parsing in browser |
| Google Fonts API | — | Font loading |

### Backend
| Package | Purpose |
|---|---|
| Python 3.11+ | Runtime |
| FastAPI | API server |
| lxml | SVG parsing + manipulation |
| CairoSVG | SVG to PNG rendering |
| Pillow | Image compositing |
| python-multipart | File upload handling |

### AI and Integrations
| Service | Purpose |
|---|---|
| Gemini 2.5 Flash (free tier) | All AI tasks — text, colour, CSV, mapping, out-of-scope handling |
| Google Fonts API | Font library |
| Unsplash API | Stock photo search (Phase 2) |
| Figma REST API | Push variants to Figma canvas (Phase 2) |

---

## What Is Already Built

### UI Prototype — `variantforge-ui.html`
Fully interactive single-file HTML prototype. Pixel-perfect visual target for React port.

**Includes:**
- Dark chrome toolbar with tool buttons, zoom pill, undo/redo
- Warm linen drafting board with paper texture + noise grain + vignette
- Major + minor graph paper grid
- Top and left ruler strips with IBM Plex Mono tick labels
- Corner registration marks + board watermark
- Variant cards with tape strip, random tilt, navy shadows
- Card select state (gold outline) + inline edit/delete controls
- Right panel: AI Chat / Layers / Style tabs
- Chat UI with typing indicator + staggered message animation
- Quick prompt chips
- Textarea prompt input with auto-resize + Enter to send
- Layer detection panel with type badges
- Colour swatch grid with active state
- Font picker
- CSV upload strip
- Export row (slides in when variants generated)
- Floating status bar pill
- Toast notification system
- All interactions simulated (upload, CSV, AI generate, select, delete)

---

## Build Order for Cursor

### Step 1 — Scaffold
```bash
npm create vite@latest variantforge -- --template react
cd variantforge
npm install tailwindcss @tailwindcss/vite
npm install fabric
npm install motion
npm install papaparse
```

### Step 2 — Port HTML to React components
Follow the component tree exactly. Use `variantforge-ui.html` as the pixel-perfect visual reference. Do not redesign anything.

### Step 3 — FastAPI backend
```bash
pip install fastapi uvicorn lxml cairosvg pillow python-multipart
```
Endpoints:
- `POST /parse-svg` → returns layer JSON
- `POST /export` → accepts variant JSON array → returns ZIP of SVG or PNG files

### Step 4 — Fabric.js board
- Single canvas instance in `<BoardSurface />`
- Pan and zoom behaviour
- Grid background via CSS (preferred over Fabric backgroundImage for performance)
- Render variant groups from JSON

### Step 5 — Inline editing + undo/redo
- Fabric `IText` for text layers
- History stack (see pattern above)
- Keyboard shortcuts: `Ctrl+Z`, `Ctrl+Shift+Z`

### Step 6 — Gemini API integration
- Every call includes the system prompt defined above
- Prompt bar sends: `{ layers: [...], prompt: "...", csv: [...] }`
- Receives: `{ variants: [ { layerId: value, ... }, ... ] }`
- Handle 429 rate limit errors gracefully with a retry queue and user-facing message
- Render each variant as a Fabric Group on the board

### Step 7 — CSV handling
- Papa Parse for file uploads in browser
- CSV stored as JSON array in memory
- Auto column mapping via Gemini
- All edits to CSV data go through Gemini via natural language — no manual editor

### Step 8 — Export
- FastAPI: receive variant JSON → render per variant via CairoSVG → ZIP → stream
- Frontend: trigger download from blob response
- Support SVG and PNG output formats

---

## Phased Rollout

### Phase 1 — MVP (2 weeks, build now)
- SVG upload + named layer detection
- Auto detection fallback for simple flat SVGs
- User layer selection as safety net for complex SVGs
- AI prompt bar (Gemini 2.5 Flash)
- CSV upload + auto column mapping via Gemini
- Gemini-driven CSV generation and editing through chat
- Out of scope handling baked into system prompt
- Fabric.js board: pan, zoom, variant cards
- Inline text editing + undo/redo
- Colour + font customisation
- SVG and PNG ZIP export
- Motion.dev UI polish

### Phase 2
- Unsplash / Pexels stock photo integration
- PDF export
- Full preview mode (click card → fullscreen overlay)
- Figma OAuth + push variants to canvas

### Phase 3
- AI image generation per variant
- User accounts + saved templates
- Shareable preview links
