# VariantForge — Handoff Instructions

## What's in this folder

| File | What it is |
|---|---|
| `variantforge-ui.html` | The visual prototype. Open in browser. Pixel-perfect target — every interaction is simulated. |
| `VARIANTFORGE_SPEC.md` | The full spec. Tech stack, component tree, build order, API patterns, design tokens. Source of truth. |
| `HANDOFF.md` | This file. |

---

## The one-line brief

A Figma-like drafting board where designers upload one SVG template, then use an AI chat bar or CSV to generate N variants with different text, images, colours, and fonts — all rendered as cards on a warm linen board.

---

## How to start

1. Open `variantforge-ui.html` in a browser first. Click everything. Understand what exists before writing code.
2. Read `VARIANTFORGE_SPEC.md` fully before starting. The build order at the bottom tells you what to do and in what sequence.
3. Port the HTML prototype to React components. Match it exactly — do not redesign anything.

---

## Key decisions already made

**AI model:** Gemini 2.5 Flash, free tier. All AI tasks go through this one model.

**CSV:** Users either upload their own CSV file or describe their data in the prompt and Gemini generates it. CSV is stored as a JSON array in memory. There is no CSV editor — all edits happen through natural language in the chat.

**SVG complexity:** Three-layer approach. Named layers (`{{variable}}`) are the recommended path for complex files. Auto detection handles simple flat SVGs. User selection in the Layers tab is the fallback for anything in between.

**Out of scope:** Baked into the Gemini system prompt. When a user asks for something the tool cannot do (animation, logo creation, photo editing, video), Gemini acknowledges it briefly, suggests what VariantForge can do instead, and points to an external tool if relevant. The full system prompt and a response table are in the spec.

**Export for MVP:** SVG and PNG ZIP only. PDF and Figma push are Phase 2.

**Rate limits:** Gemini free tier returns 429 errors at 15 RPM. Handle gracefully with a retry queue and a short user-facing message in the chat.

---

## Critical design details to preserve

- Board surface: warm linen `#F0EDE4` with graph paper grid, paper noise texture, and vignette
- All shadows use `rgba(18,28,60,...)` — navy tinted, never pure black
- Cards have a slight random tilt (plus or minus 0.5deg) and a translucent tape strip on top
- Hover on card: snaps straight, lifts with deeper navy shadow
- Selected card: `2px solid #C8A96E` gold outline
- Ruler strips use IBM Plex Mono
- Right panel is dark `rgba(30,30,26,0.97)` — contrasts against the warm board
- Accent colour throughout panel: `#C8A96E` gold

---

## Start command

```bash
npm create vite@latest variantforge -- --template react
cd variantforge
npm install tailwindcss @tailwindcss/vite fabric motion papaparse
```

Then follow Steps 1 through 8 in `VARIANTFORGE_SPEC.md`.
